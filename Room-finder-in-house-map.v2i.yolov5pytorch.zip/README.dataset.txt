# Room-finder-in-house-map > 2025-08-30 11:15pm
https://universe.roboflow.com/new-workspace-t0qyi/room-finder-in-house-map-zmxjm

Provided by a Roboflow user
License: CC BY 4.0

